<?php


return [
    'list_user' => 'VER TODOS OS USUÁRIOS',
    'view_user' => 'VER USUÁRIO',
    'edit_user' => 'EDITAR USUÁRIO',
    'change_password' => 'TROCAR SENHA DO USUÁRIO',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
];
