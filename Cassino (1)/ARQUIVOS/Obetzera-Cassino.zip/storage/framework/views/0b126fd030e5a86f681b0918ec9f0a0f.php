<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split(TomatoPHP\FilamentSimpleTheme\Livewire\TopBarStart::class);

$__html = app('livewire')->mount($__name, $__params, 'lw-3069924937-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH /var/www/sistema_ativo/storage/framework/views/2d8ec38c2f9a917984635f0c346ae4f9.blade.php ENDPATH**/ ?>