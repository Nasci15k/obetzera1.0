<div 
    class="absolute inset-0 bg-white/30 flex items-center justify-center" 
    style="backdrop-filter: blur(5px); background-color: rgba(255, 255, 255, 0.3);"
>
    <span class="text-gray-800 text-lg font-semibold">
        🔒 Área bloqueada! Falta {{ $minutes }} minuto(s) para você poder editar novamente.
    </span>
</div>