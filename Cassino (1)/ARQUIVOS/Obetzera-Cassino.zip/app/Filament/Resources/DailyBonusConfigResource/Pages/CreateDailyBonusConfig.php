<?php

namespace App\Filament\Resources\DailyBonusConfigResource\Pages;

use App\Filament\Resources\DailyBonusConfigResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDailyBonusConfig extends CreateRecord
{
    protected static string $resource = DailyBonusConfigResource::class;
}
