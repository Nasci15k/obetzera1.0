<?php

namespace App\Filament\Resources\MinesConfigResource\Pages;

use App\Filament\Resources\MinesConfigResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMinesConfig extends CreateRecord
{
    protected static string $resource = MinesConfigResource::class;
}
