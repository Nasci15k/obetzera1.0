<?php

namespace App\Filament\Resources\CupomResource\Pages;

use App\Filament\Resources\CupomResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCupom extends CreateRecord
{
    protected static string $resource = CupomResource::class;
}
