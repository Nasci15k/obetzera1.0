<?php

namespace App\Filament\Resources\AffiliateWithdrawResource\Pages;

use App\Filament\Resources\AffiliateWithdrawResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAffiliateWithdraw extends CreateRecord
{
    protected static string $resource = AffiliateWithdrawResource::class;
}
